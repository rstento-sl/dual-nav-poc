#!/bin/bash

python3.8 /opt/remote_python_executor_data/remote_python_executor.py 5301